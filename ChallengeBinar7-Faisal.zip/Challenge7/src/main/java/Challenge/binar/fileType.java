package Challenge.binar;

public enum fileType {
    PNG,
    JPG,
    JPEG
}
